﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Proyecto_ENE.Entities
{
    public class Usuario
    {
        public string usuario { get; set; }
        public string clave { get; set; }
        public string tipo { get; set; } 

    }
}
